<div class="app-item col-12 col-md-6">
    <a data-fancybox href="assets/images/portfolio/logo/1.png" class="bg-container" style="background-image: url(assets/images/portfolio/logo/1.png)">
        <div class="mask">
            <div class="content black">
                <h2>Logo Design</h2><span>Graphic design</span>
                <div class="svg-wrap">
                    <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                        <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                            <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#000000">
                                <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                            </g>
                        </g>
                    </svg>
                </div>
            </div>
        </div>
    </a>
</div>

                    
<div class="app-item col-12 col-md-6">
    <a data-fancybox href="assets/images/portfolio/logo/2.png" class="bg-container" style="background-image: url(assets/images/portfolio/logo/2.png)">
        <div class="mask">
            <div class="content black">
                <h2>Logo Design</h2><span>Graphic design</span>
                <div class="svg-wrap">
                    <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                        <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                            <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#000000">
                                <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                            </g>
                        </g>
                    </svg>
                </div>
            </div>
        </div>
    </a>
</div>
<div class="app-item col-12 col-md-6">
    <a data-fancybox href="assets/images/portfolio/logo/3.png" class="bg-container" style="background-image: url(assets/images/portfolio/logo/3.png)">
        <div class="mask">
            <div class="content black">
                <h2>Logo Design</h2><span>Graphic design</span>
                <div class="svg-wrap">
                    <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                        <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                            <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#000000">
                                <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                            </g>
                        </g>
                    </svg>
                </div>
            </div>
        </div>
    </a>
</div>
<div class="app-item col-12 col-md-6">
    <a data-fancybox href="assets/images/portfolio/logo/4.png" class="bg-container" style="background-image: url(assets/images/portfolio/logo/4.png)">
        <div class="mask">
            <div class="content black">
                <h2>Logo Design</h2><span>Graphic design</span>
                <div class="svg-wrap">
                    <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                        <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                            <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#000000">
                                <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                            </g>
                        </g>
                    </svg>
                </div>
            </div>
        </div>
    </a>
</div>
<div class="app-item col-12 col-md-6">
    <a data-fancybox href="assets/images/portfolio/logo/5.png" class="bg-container" style="background-image: url(assets/images/portfolio/logo/5.png)">
        <div class="mask">
            <div class="content black">
                <h2>Logo Design</h2><span>Graphic design</span>
                <div class="svg-wrap">
                    <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                        <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                            <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#000000">
                                <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                            </g>
                        </g>
                    </svg>
                </div>
            </div>
        </div>
    </a>
</div>
<div class="app-item col-12 col-md-6">
    <a data-fancybox href="assets/images/portfolio/logo/6.png" class="bg-container" style="background-image: url(assets/images/portfolio/logo/6.png)">
        <div class="mask">
            <div class="content black">
                <h2>Logo Design</h2><span>Graphic design</span>
                <div class="svg-wrap">
                    <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                        <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                            <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#000000">
                                <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                            </g>
                        </g>
                    </svg>
                </div>
            </div>
        </div>
    </a>
</div>
<div class="app-item col-12 col-md-6">
    <a data-fancybox href="assets/images/portfolio/logo/7.png" class="bg-container" style="background-image: url(assets/images/portfolio/logo/7.png)">
        <div class="mask">
            <div class="content black">
                <h2>Logo Design</h2><span>Graphic design</span>
                <div class="svg-wrap">
                    <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                        <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                            <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#000000">
                                <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                            </g>
                        </g>
                    </svg>
                </div>
            </div>
        </div>
    </a>
</div>
<div class="app-item col-12 col-md-6">
    <a data-fancybox href="assets/images/portfolio/logo/8.png" class="bg-container" style="background-image: url(assets/images/portfolio/logo/8.png)">
        <div class="mask">
            <div class="content black">
                <h2>Logo Design</h2><span>Graphic design</span>
                <div class="svg-wrap">
                    <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                        <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                            <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#000000">
                                <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                            </g>
                        </g>
                    </svg>
                </div>
            </div>
        </div>
    </a>
</div>
<div class="app-item col-12 col-md-6">
    <a data-fancybox href="assets/images/portfolio/logo/9.png" class="bg-container" style="background-image: url(assets/images/portfolio/logo/9.png)">
        <div class="mask">
            <div class="content black">
                <h2>Logo Design</h2><span>Graphic design</span>
                <div class="svg-wrap">
                    <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                        <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                            <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#000000">
                                <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                            </g>
                        </g>
                    </svg>
                </div>
            </div>
        </div>
    </a>
</div>
<div class="app-item col-12 col-md-6">
    <a data-fancybox href="assets/images/portfolio/logo/10.png" class="bg-container" style="background-image: url(assets/images/portfolio/logo/10.png)">
        <div class="mask">
            <div class="content black">
                <h2>Logo Design</h2><span>Graphic design</span>
                <div class="svg-wrap">
                    <svg width="28px" height="12px" viewBox="0 0 28 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                        <g id="Main-page" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                            <g id="icons" class="icon-arrow" transform="translate(-714.000000, -120.000000)" fill="#000000">
                                <path d="M737.608907,124.700519 L734.322602,121.414214 L735.736815,120 L739.990251,124.253436 L740.001047,124.242641 L741.41526,125.656854 L741.404465,125.66765 L741.41526,125.678445 L740.001047,127.092659 L739.990251,127.081863 L735.736815,131.3353 L734.322602,129.921086 L737.543169,126.700519 L714,126.700519 L714,124.700519 L737.608907,124.700519 Z" id="Combined-Shape"></path>
                            </g>
                        </g>
                    </svg>
                </div>
            </div>
        </div>
    </a>
</div>

<div class="col-md-12 text-center">
            <a href="javascript:;" class="viewmorebtn" id="loadMorelogo">View More</a>
        </div>