<div class="col-sm-4">
  <div class="packagebox">
    <p class="populartag">&nbsp;</p>
    <div class="">
      <div class="packhdbox">
        <h3 >Startup Package</h3>
        <p class="">Startup</p>
      </div>
      <div class="packpricing">
        <h2>$699 <span class="strike">$1299</span></h2>
      </div>
      <div class="packinner">
        <p>The most important functional ties for your teams-perfectly integrated from one vendor.</p>
      </div>
      <button class="packbtn" onClick="order?pack=7">Order Now</button>
      <div class="list-scroll">
        <ul class="details">
          <li><strong>3</strong> postings per week (per network) Facebook + Twitter + Instagram + Google+ </li>
          <li>Content Creation </li>
          <li>Business Page Optimization </li>
          <li>Social Media Strategy (Overview) </li>
          <li>Facebook Likes Campaign </li>
          <li>Monthly Progress report </li>
          <li>Copy Writing</li>
        </ul>
      </div>
      <div class="addnotes ">
        <p>&nbsp;</p>
        
        
      </div>
      <a href="javascript:;" class="chatbtn"><i class=""></i> Live Chat</a>
      <a href="tel:18627721016" class="numberbtn"><i class=""></i>+1 862 772 1016</a>
    </div>
  </div>
</div>
<div class="col-sm-4">
  <div class="packagebox">
    <p class="populartag">Popular</p>
    <div class="">
      <div class="packhdbox">
        <h3 >Scaling Package</h3>
        <p class="">Essentials</p>
      </div>
      <div class="packpricing">
        <h2>$799.99 <span class="strike">$1599.99</span></h2>
      </div>
      <div class="packinner">
        <p>The most important functional ties for your teams-perfectly integrated from one vendor.</p>
      </div>
      <button class="packbtn" onClick="order?pack=8">Order Now</button>
      <div class="list-scroll">
        <ul class="details">
          <li>Copywriting &amp; Visual designs </li>
          <li>Business Page Optimization </li>
          <li>Ad Campaign Management </li>
          <li>Spam monitoring </li>
          <li>Monthly Progress report </li>
          <li><strong>5</strong> postings per week Facebook + Twitter + Instagram + Google+ </li>
          <li>Reputation Management </li>
          <li>Social Account Setup </li>
          <li>Content Creation </li>
          <li>Social Media Listening </li>
          <li>Query and comments reply</li>
        </ul>
        
      </div>
      <div class="addnotes ">
        <p>&nbsp;</p>
        
        
      </div>
      <a href="javascript:;" class="chatbtn"><i class=""></i> Live Chat</a>
      <a href="tel:18627721016" class="numberbtn"><i class=""></i>+1 862 772 1016</a>
    </div>
  </div>
</div>
<div class="col-sm-4">
  <div class="packagebox">
    <p class="populartag">&nbsp;</p>
    <div class="">
      <div class="packhdbox">
        <h3 >Venture Package</h3>
        <p class="">Business</p>
      </div>
      <div class="packpricing">
        <h2>$1200.99 <span class="strike">$2999.99</span></h2>
      </div>
      <div class="packinner">
        <p>The most important functional ties for your teams-perfectly integrated from one vendor.</p>
      </div>
      <button class="packbtn" onClick="order?pack=9">Order Now</button>
      <div class="list-scroll">
        <ul class="details">
          <li>Copywriting &amp; Visual designs </li>
          <li>Business Page Optimization </li>
          <li>Ad Campaign Management </li>
          <li>Spam monitoring </li>
          <li><strong>6</strong> postings per week Facebook + Twitter + Instagram + Google+  </li>
          <li>Reputation Management </li>
          <li>Social Account Setup </li>
          <li>Content Creation </li>
          <li>Social Media Hearing </li>
          <li>Query and comments reply</li>
        </ul>
        
      </div>
      <div class="addnotes ">
        <p>&nbsp;</p>
        
        
      </div>
      <a href="javascript:;" class="chatbtn"><i class=""></i> Live Chat</a>
      <a href="tel:18627721016" class="numberbtn"><i class=""></i>+1 862 772 1016</a>
    </div>
  </div>
</div>