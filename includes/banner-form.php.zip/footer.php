


         
   

    </div>
    </div>






    





<div class="floatbutton">
    <div class="btns_wrap">
            
            <a href="javascript:;" class="chat_wrap" onclick="$zopim.livechat.window.toggle()">
              <span class="icoo"><i class="fa fa-comment"></i></span>
              <span>Chat With Us</span>
            </a>
            <a href="tel:+18627721016" class="call_wrap">
             <span class="icoo"><i class="fa fa-phone"></i></span>
              <span> +1 862 772 1016 </span>
            </a>
          </div>


      <div class="clickbutton"><div class="crossplus"><i class="fa fa-send"></i></div></div>
      <div class="banner-form">
        <h3>Chat With Us to <br><Strong>Avail 50% Discount</Strong></h3>
        <div class="banform">
          <div class="container">
            <div class="row">
                <div class="ban-form">
                  <form class="cmxform" id="bannerform"  method="POST" action="webpages/floatingFormController.php">
                    <div class="row">
                      <div class="col-lg-12">
                        <div class="fldset">
                          <input id="username" name="fName" minlength="2" type="text" placeholder="Enter your name" required />
                        </div>
                      </div>
                      <div class="col-lg-12">
                        <div class="fldset">
                          <input id="cemail" type="email" name="fEmail" placeholder="Enter email here" required>
                        </div>
                      </div>
                      <div class="col-lg-12">
                        <div class="fldset">
                          <input id="phone-coun" name="fNumber" type="number" placeholder="Phone Number" required />
                        </div>
                      </div>
                      <div class="col-lg-12">
                        <div class="fldset">
                          <textarea name="fMessage" id="" rows="7" placeholder="Talk About Your Project"></textarea>
                        </div>
                      </div>
                      
                      <div class="col-lg-12">
                        <div class="fldset">
                          <input name="submit" type="submit" placeholder="Connect With Us" required />
        
                          <script type="text/javascript">
                        document.getElementById('flocation').value = window.location.href;
                      </script>
                      <input type="hidden" name="hiddencapcha" value="">
                      <input type="hidden" id="flocation" name="flocationURL" value="" />
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
            </div>
          </div>
        </div>  
    </div>
    </div>



<div class="ys-layer"></div>
<div class="ys-container" id="ys-container">
   <div class="ys-box">
       <a class="ys-popup-close ys-exit" href="#">x</a>
       <img src="assets/images/form-banner.jpg" class="mainbann" alt="">
       <div class="ys-popup-content">
           <!-- <p>Are Your Sure?</p>
           <a href="#" class="ys-exit">Exit</a> -->

           <div class="popupform tabform clearfix  text-left">
             <h2 class="text-center">Design Dok help you to design a custom logo design. Work with experienced designers to create a logo that will grow your brand.</h2>
             <form id="popupfrm" class="cmxform"  method="POST" action="webpages/floatingFormController.php">

               <div class="fldst">
                 <input id="username" name="fName" minlength="2" type="text" placeholder="Enter your name" required />
               </div>

               <div class="fldst fldstrght">
                 <input id="cemail" type="email" name="fEmail" placeholder="Enter email here" required>
               </div>

               <div class="fldst">
                 <input id="phone-coun" name="fNumber" required="" type="number" rangelength="[2,15]" placeholder="Enter phone here">
                 <script type="text/javascript">
                document.getElementById('location').value = window.location.href;
              </script>
              <input type="hidden" name="hiddencapcha" value="">
              
              <input type="hidden" id="location" name="flocationURL" value="<?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']; ?>" />
               </div>

               
               <div class="fldst btnattach">
                 <!-- <input class="submit" type="submit" value="" class="btnsb" /> -->
                 <button type="submit" form="popupfrm" value="Submit"><span class="icon-paperplane plane"></span> Let's Explainify & Grow Business</button>

               </div>
               <p class="lst-p">Discuss With Our Strategic Consultant <span><a href="tel:18627721016">+1 862 772 1016</a></span></p>

             </form>
           </div>
       </div>
   </div>
</div>


<script type='text/javascript' src='assets/js/mlib.js'></script>
<script type='text/javascript' src='assets/js/functions.js'></script>
<script type='text/javascript' src='assets/js/gsapAnimation.js'></script>

<!-- Start of  Zendesk Widget script -->
<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=2d3ea58c-6b86-47de-b84e-8c32aa63713a"> </script>
<!-- End of  Zendesk Widget script -->
<script type="text/javascript">
function setButtonURL(){
javascript:$zopim.livechat.window.show();
}

$(document).on("click",".chatbtn",function(){
      javascript:$zopim.livechat.window.show();
});


</script>


<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.js"></script>-->

<!--<script>-->
<!--var options = {-->
<!--debug: false,-->
<!--}-->







<!--if ($.cookie('ysExit') == 1)-->
<!--     {-->

<!--     }-->
<!--else{-->
<!-- ysExit(options);-->
<!--}-->

<!--</script>-->



<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-139554973-1"></script>
<script>
 window.dataLayer = window.dataLayer || [];
 function gtag(){dataLayer.push(arguments);}
 gtag('js', new Date());

 gtag('config', 'UA-139554973-1');





</script>