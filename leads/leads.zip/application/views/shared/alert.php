<!DOCTYPE html>
<html lang="en">
<head>
    <?php $this->load->view("shared/head");?>
</head>
<body>
	
    <div class="container">
        
    	<div class="row">
    	
    		<br>
    		
    		<div class="col-md-offset-3 col-md-6">
    		
    			<?php $this->load->view("partials/message_error", $data);?>
    			
    		</div><!-- /.col-md-12 -->
    	</div>
    </div>
    <!-- /.container -->

  </body>
</html>
