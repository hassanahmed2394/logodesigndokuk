<div class="alert alert-success">
	<button type="button" class="close fui-cross" data-dismiss="alert"></button>
  	<?php if(isset($success_message_heading)):?><h4><?php echo $success_message_heading;?></h4><?php endif;?>
  	<p>
  		<?php echo $success_message;?>
  	</p>
</div>